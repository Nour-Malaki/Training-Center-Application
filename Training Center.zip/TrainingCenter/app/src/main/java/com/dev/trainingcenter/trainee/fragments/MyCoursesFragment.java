package com.dev.trainingcenter.trainee.fragments;

import static androidx.navigation.fragment.FragmentKt.findNavController;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.admin.adapter.CoursesAdapter;
import com.dev.trainingcenter.common.Constants;
import com.dev.trainingcenter.common.CourseModel;
import com.dev.trainingcenter.common.Helper;
import com.dev.trainingcenter.common.OnCLick;
import com.dev.trainingcenter.common.RequestStatus;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.FragmentMyCoursesBinding;

import java.util.List;

public class MyCoursesFragment extends Fragment implements OnCLick {

    FragmentMyCoursesBinding binding;
    CoursesAdapter adapter;
    List<CourseModel> list;
    DatabaseHelper helper;

    public MyCoursesFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentMyCoursesBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        helper = new DatabaseHelper(requireContext());
        list = helper.getApprovedCourses(Helper.userModel.getId(), RequestStatus.APPROVED.name());

        adapter = new CoursesAdapter(list, requireContext(), this);
        binding.rvCourse.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvCourse.setAdapter(adapter);

        if (list.size()==0){
            binding.noData.getRoot().setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void ClickListener(int pos) {
        Bundle bundle=new Bundle();
        bundle.putLong(Constants.ID,list.get(pos).getId());
        findNavController(MyCoursesFragment.this).navigate(R.id.action_nav_my_courses_to_courseDetailsFragment,bundle);
    }
}