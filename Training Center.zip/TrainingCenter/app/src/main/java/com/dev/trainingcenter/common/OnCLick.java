package com.dev.trainingcenter.common;

public interface OnCLick {
    public void ClickListener(int pos);
}
