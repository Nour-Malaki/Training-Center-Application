package com.dev.trainingcenter.admin.fragments;

import static androidx.navigation.fragment.FragmentKt.findNavController;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.admin.adapter.CoursesAdapter;
import com.dev.trainingcenter.common.Constants;
import com.dev.trainingcenter.common.CourseModel;
import com.dev.trainingcenter.common.CourseStatus;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.FragmentHomeBinding;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    CoursesAdapter adapter;
    List<CourseModel> list;
    DatabaseHelper helper;
    List<CourseModel> filterList;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        helper = new DatabaseHelper(requireContext());
        list = helper.getAllCourses();
        adapter = new CoursesAdapter(list, requireContext(), pos -> {
            Bundle bundle = new Bundle();
            bundle.putSerializable(Constants.ID, list.get(pos).getId());
            findNavController(HomeFragment.this).navigate(R.id.action_nav_home_to_courseDetailsAdminFragment, bundle);
        });
        for (CourseModel model : list
        ) {
            if (model.getEndDate() < System.currentTimeMillis()) {
                model.setStatus(CourseStatus.CLOSED.name());
                helper.updateCourse(model);
            } else if (model.getStatus().equals(CourseStatus.CLOSED.name())) {
                model.setStatus(CourseStatus.OPEN.name());
                helper.updateCourse(model);
            }
        }

        binding.rvCourse.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvCourse.setAdapter(adapter);
        if (list.size() == 0) {
            binding.noData.tvTitle.setText("No Courses so far please add course");
            binding.noData.getRoot().setVisibility(View.VISIBLE);
        }

        binding.search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().isEmpty()) {

                } else {
                    filterList = new ArrayList<>();
                    for (CourseModel model : list) {
                        if (model.getTitle().toLowerCase(Locale.ROOT).contains(s.toString().toLowerCase(Locale.ROOT))) {
                            filterList.add(model);
                        }
                    }
                    adapter.setList(filterList);
                }
            }
        });

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}