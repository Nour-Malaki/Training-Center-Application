package com.dev.trainingcenter.common;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class Utils {

    public static String listToString(List<String> list) {
        String result_string = String.join(" ", list);
        return result_string;
    }

    public static List<String> stringToList(String jsonString) {
        ArrayList<String> array_list = new ArrayList<>(Arrays.asList(jsonString.split(" ")));
        return array_list;
    }

    public static String formatDate(long date) {
        return new SimpleDateFormat("dd/MM/yyyy hh:mm").format(new Date(date));
    }
}
