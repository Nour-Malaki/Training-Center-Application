package com.dev.trainingcenter.admin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.admin.adapter.StudentsAdapter;
import com.dev.trainingcenter.auth.UserModel;
import com.dev.trainingcenter.common.Constants;
import com.dev.trainingcenter.common.OnCLick;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.ActivitySelectInstuctorBinding;

import java.util.List;

public class SelectInstuctorActivity extends AppCompatActivity implements OnCLick {
    ActivitySelectInstuctorBinding binding;

    StudentsAdapter adapter;
    List<UserModel> list;
    DatabaseHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivitySelectInstuctorBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        helper=new DatabaseHelper(this);
        list=helper.getUsersByType(Constants.INSTRUCTOR);
        adapter=new StudentsAdapter(list,this,this);
        binding.rvInstructors.setLayoutManager(new LinearLayoutManager(this));
        binding.rvInstructors.setAdapter(adapter);


    }

    @Override
    public void ClickListener(int pos) {
        Intent intent=new Intent();
        intent.putExtra(Constants.MODEL,list.get(pos));
        setResult(Activity.RESULT_OK,intent);
        finish();
    }
}