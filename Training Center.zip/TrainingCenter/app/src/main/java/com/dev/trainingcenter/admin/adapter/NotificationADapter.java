package com.dev.trainingcenter.admin.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.common.Helper;
import com.dev.trainingcenter.common.RequestCourseModel;
import com.dev.trainingcenter.common.RequestStatus;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.ListNotificationsBinding;

import java.util.List;

public class NotificationADapter extends RecyclerView.Adapter<NotificationADapter.Vh> {
    List<RequestCourseModel> list;
    Context context;

    DatabaseHelper helper;

    public NotificationADapter(List<RequestCourseModel> list, Context context, DatabaseHelper helper) {
        this.list = list;
        this.context = context;
        this.helper = helper;
    }

    @NonNull
    @Override
    public Vh onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_notifications, parent, false);
        return new Vh(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Vh holder, int position) {
        RequestCourseModel requestCourseModel = list.get(position);
        holder.binding.tvUser.setText(requestCourseModel.getCourseName());
        if (requestCourseModel.getUserId()!=0) {
            switch (RequestStatus.valueOf(requestCourseModel.getStatus())) {
                case PENDING:
                    if (Helper.userModel == null) {
                        holder.binding.tvRequestDetails
                                .setText(requestCourseModel.getUserName() + " Has requested to get course " + requestCourseModel.getCourseName() + " With Price of " + requestCourseModel.getPrice());
                    } else {
                        holder.binding.tvRequestDetails
                                .setText(" Your request to enroll " + requestCourseModel.getCourseName() + " With Price of " + requestCourseModel.getPrice() + " Has been Received.");

                    }
                    break;
                case APPROVED:
                    if (Helper.userModel == null) {
                        holder.binding.tvRequestDetails
                                .setText("You have Approved course " + requestCourseModel.getCourseName() + " for " + requestCourseModel.getUserName() + " With Price of " + requestCourseModel.getPrice());
                    } else {
                        holder.binding.tvRequestDetails
                                .setText("Congratulations You have Successfully enrolled  " + requestCourseModel.getCourseName() + " With Price of " + requestCourseModel.getPrice());
                    }
                    break;
                case REJECTED:
                    if (Helper.userModel == null) {
                        holder.binding.tvRequestDetails
                                .setText("You have Rejected course " + requestCourseModel.getCourseName() + " for " + requestCourseModel.getUserName() + " With Price of " + requestCourseModel.getPrice());
                    } else {
                        holder.binding.tvRequestDetails
                                .setText("Unfortunately we have Rejected your request for course " + requestCourseModel.getCourseName());
                    }
                    break;
            }
        }else {
            holder.binding.tvRequestDetails.setText("Our course "+ requestCourseModel.getCourseName()+" is up for Registration Check it now!!");
        }

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class Vh extends RecyclerView.ViewHolder {
        ListNotificationsBinding binding;

        public Vh(@NonNull View itemView) {
            super(itemView);
            binding = ListNotificationsBinding.bind(itemView);
        }
    }

}