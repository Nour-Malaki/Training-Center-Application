package com.dev.trainingcenter.trainee.fragments;

import static androidx.navigation.fragment.FragmentKt.findNavController;

import android.net.Uri;
import android.os.Bundle;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.dev.trainingcenter.auth.UserModel;
import com.dev.trainingcenter.common.Constants;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.FragmentTraineeEditProfileBinding;

public class TraineeEditProfileFragment extends Fragment {
    FragmentTraineeEditProfileBinding binding;
    UserModel model;
    DatabaseHelper helper;
    String image;

    public TraineeEditProfileFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            model = (UserModel) getArguments().getSerializable(Constants.MODEL);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentTraineeEditProfileBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (model != null) {
            helper=new DatabaseHelper(requireContext());
            binding.ivImage.setImageURI(Uri.parse(model.getImage()));
            binding.firstName.setText(model.getFirstName());
            binding.lastName.setText(model.getLastName());
            binding.address.setText(model.getAddress());
            binding.phone.setText(model.getPhone());
            binding.email.setText(model.getEmail());
            image = model.getImage();

            binding.btnEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String name = binding.firstName.getText().toString();
                    String lName = binding.lastName.getText().toString();
                    String address = binding.address.getText().toString();
                    String phone = binding.phone.getText().toString();
                    String email = binding.email.getText().toString();

                    if (image == null) {
                        showToast("Please pick image");
                    } else if (email.isEmpty()) {
                        showToast("Please enter email");
                        binding.email.setError("Please enter email");
                    } else if (!(Patterns.EMAIL_ADDRESS).matcher(email).matches()) {
                        showToast("Please enter email in correct format");
                        binding.email.setError("Please enter email in correct format");
                    } else if (name.isEmpty()) {
                        showToast("Please enter first name");
                        binding.firstName.setError("Please enter first name");
                    } else if (lName.isEmpty()) {
                        showToast("Please enter last name");
                        binding.lastName.setError("Please enter last name");
                    } else if (phone.isEmpty()) {
                        showToast("Please enter mobile number");
                        binding.phone.setError("Please enter mobile number");
                    } else if (address.isEmpty()) {
                        showToast("Please enter address");
                        binding.address.setError("Please enter address");
                    }

                    model.setFirstName(name);
                    model.setLastName(lName);
                    model.setAddress(address);
                    model.setEmail(email);
                    model.setPhone(phone);
                    model.setImage(image);
                    Integer id = helper.updateUser(model);
                    if (id > 0) {
                        findNavController(TraineeEditProfileFragment.this).navigateUp();
                    }
                }
            });
        }


    }

    private void showToast(String message) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    }
}