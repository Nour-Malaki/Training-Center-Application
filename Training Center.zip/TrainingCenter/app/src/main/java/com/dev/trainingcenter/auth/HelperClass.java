package com.dev.trainingcenter.auth;

public class HelperClass {
    public static UserModel users;
}
