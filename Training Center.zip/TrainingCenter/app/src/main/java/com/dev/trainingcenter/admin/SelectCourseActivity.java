package com.dev.trainingcenter.admin;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.dev.trainingcenter.admin.adapter.CoursesAdapter;
import com.dev.trainingcenter.common.Constants;
import com.dev.trainingcenter.common.CourseModel;
import com.dev.trainingcenter.common.OnCLick;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.ActivitySelectCourseBinding;

import java.util.ArrayList;
import java.util.List;

public class SelectCourseActivity extends AppCompatActivity implements OnCLick {
    ActivitySelectCourseBinding binding;
    CoursesAdapter adapter;
    DatabaseHelper helper;
    List<CourseModel> list;
    CourseModel model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySelectCourseBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        helper=new DatabaseHelper(this);
        Long id = getIntent().getLongExtra(Constants.ID, -1);
        if (id != -1) {
            model = helper.getCourseById(id);
        }

        helper = new DatabaseHelper(this);
        list = new ArrayList<>();
        if (model != null) {
            for (CourseModel model1 : helper.getAllCourses()) {
                if (model1.getId() != model.getId() ) {
                    if (model1.getPre_requesties()!=null && !model1.getPre_requesties().contains(String.valueOf(model.getId()))) {
                        list.add(model1);
                    }
                }
            }
        }else {
            list=helper.getAllCourses();
        }

        binding.rvCourse.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CoursesAdapter(list, this, this);
        binding.rvCourse.setAdapter(adapter);
        if (list.size() == 0) {
            binding.noData.getRoot().setVisibility(View.VISIBLE);
            binding.noData.tvTitle.setText("No Courses To select");
        }
    }

    @Override
    public void ClickListener(int pos) {
        Intent intent = new Intent();
        intent.putExtra(Constants.ID, list.get(pos).getId());
        setResult(Activity.RESULT_OK, intent);
        finish();
    }
}