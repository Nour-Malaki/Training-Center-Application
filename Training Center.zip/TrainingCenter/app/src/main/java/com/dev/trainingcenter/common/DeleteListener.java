package com.dev.trainingcenter.common;

public interface DeleteListener {
    public void pos(int pos);
}
