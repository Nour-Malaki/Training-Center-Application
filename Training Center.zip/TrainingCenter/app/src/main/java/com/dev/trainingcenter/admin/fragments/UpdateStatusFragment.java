package com.dev.trainingcenter.admin.fragments;

import static androidx.navigation.fragment.FragmentKt.findNavController;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.dev.trainingcenter.admin.SelectInstuctorActivity;
import com.dev.trainingcenter.auth.UserModel;
import com.dev.trainingcenter.common.Constants;
import com.dev.trainingcenter.common.CourseModel;
import com.dev.trainingcenter.common.CourseStatus;
import com.dev.trainingcenter.common.RequestCourseModel;
import com.dev.trainingcenter.common.Slots;
import com.dev.trainingcenter.common.Utils;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.FragmentUpdateStatusBinding;
import com.skydoves.powermenu.PowerMenu;
import com.skydoves.powermenu.PowerMenuItem;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class UpdateStatusFragment extends Fragment {

    FragmentUpdateStatusBinding binding;
    CourseModel updateModel;
    private int mYear, mMonth, mDay, mHour, mMinute;
    Long id;
    String instructorName;
    DatabaseHelper helper;

    public UpdateStatusFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            updateModel = (CourseModel) getArguments().getSerializable(Constants.MODEL);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentUpdateStatusBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (updateModel != null) {
            binding.tvTitle.setText("Update " + updateModel.getTitle() + " Availability");
            if (updateModel.getDeadline() != null) {
                if (updateModel.getDeadline() != 0) {
                    binding.etDeadline.setText(Utils.formatDate(updateModel.getDeadline()));
                }
                binding.etStart.setText(Utils.formatDate(updateModel.getStartDate()));
                binding.etInstructor.setText(updateModel.getInstructorName());
                binding.etSlot.setText(updateModel.getSlot());
                binding.etVenue.setText(updateModel.getVenue());
            }
        }


        binding.etInstructor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(requireContext(), SelectInstuctorActivity.class);
                requireActivity().startActivityFromFragment(UpdateStatusFragment.this, intent, 100);
            }
        });
        binding.etSlot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMenuType(view);
            }
        });

        binding.etStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowDatePicker(binding.etStart);
            }
        });

        binding.etDeadline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowDatePicker(binding.etDeadline);
            }
        });

        binding.btnUpdateAvailability.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String startTime = binding.etStart.getText().toString();
                String deadline = binding.etDeadline.getText().toString();
                String venue = binding.etVenue.getText().toString();
                String slot = binding.etSlot.getText().toString();

                if (startTime.isEmpty()) {
                    Toast.makeText(requireContext(), "Start Time is Empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (deadline.isEmpty()) {
                    Toast.makeText(requireContext(), "Deadline is Empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (venue.isEmpty()) {
                    Toast.makeText(requireContext(), "Venue is Empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (slot.isEmpty()) {
                    Toast.makeText(requireContext(), "Slot is Empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (instructorName==null) {
                    Toast.makeText(requireContext(), "Select Instructor", Toast.LENGTH_SHORT).show();
                    return;
                }
                updateModel.setStatus(CourseStatus.OPEN.name());
                updateModel.setDeadline(formatTime(deadline));
                updateModel.setStartDate(formatTime(startTime));
                updateModel.setSlot(slot);
                updateModel.setVenue(venue);
                updateModel.setInstructorId(id);
                updateModel.setInstructorName(instructorName);

                helper = new DatabaseHelper(requireContext());
                long id = helper.updateCourse(updateModel);
                if (id!=0){
                    RequestCourseModel model=new RequestCourseModel();
                    model.setStatus(null);
                    model.setPrice(updateModel.getPrice());
                    model.setCourseId(updateModel.getId());
                    model.setTime(System.currentTimeMillis());
                    model.setUserName(null);
                    model.setCourseName(updateModel.getTitle());

                    helper.addRequest(model);
                }
                Log.e("TAG", "onClick: " + id);
                findNavController(UpdateStatusFragment.this).navigateUp();

            }
        });
    }

    private void showMenuType(View view) {
        PowerMenu powerMenu = new PowerMenu.Builder(requireContext())
                .setTextColor(Color.BLACK)
                .setMenuRadius(10f)
                .setTextGravity(Gravity.CENTER)
                .addItem(new PowerMenuItem(Slots.MORNING.name()))
                .addItem(new PowerMenuItem(Slots.NOON.name()))
                .addItem(new PowerMenuItem(Slots.AFTERNOON.name()))
                .addItem(new PowerMenuItem(Slots.EVENING.name()))
                .addItem(new PowerMenuItem(Slots.NIGHT.name()))
                .build();

        powerMenu.setOnMenuItemClickListener((position, item) -> {
            binding.etSlot.setText(item.getTitle());

            powerMenu.dismiss();
        });

        powerMenu.showAtCenter(view);
    }


    private void ShowDatePicker(EditText editText) {
        // Get Current Date
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        DatePickerDialog datePickerDialog = new DatePickerDialog(requireContext(),
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {
                        mDay = dayOfMonth;
                        mMonth = monthOfYear + 1;
                        mYear = year;
                        showTimePicker(editText);

                    }
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }

    private void showTimePicker(EditText editText) {
        final Calendar c = Calendar.getInstance();
        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);

        // Launch Time Picker Dialog
        TimePickerDialog timePickerDialog = new TimePickerDialog(requireContext(),
                new TimePickerDialog.OnTimeSetListener() {

                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay,
                                          int minute) {
                        mHour = hourOfDay;
                        mMinute = minute;
                        editText.setText(mDay + "/" + mMonth + "/" + mYear + " " + mHour + ":" + mMinute);
                    }
                }, mHour, mMinute, false);
        timePickerDialog.show();
    }

    private Long formatTime(String date) {
        long millis = 0;
        SimpleDateFormat f = new SimpleDateFormat("dd/MM/yyyy hh:mm");
        try {
            Date d = f.parse(date);
            millis = d.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return millis;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            UserModel userData = (UserModel) (data != null ? data.getSerializableExtra(Constants.MODEL) : null);
            id = userData.getId();
            instructorName = userData.getFirstName();
            binding.etInstructor.setText(instructorName);
        }
    }
}