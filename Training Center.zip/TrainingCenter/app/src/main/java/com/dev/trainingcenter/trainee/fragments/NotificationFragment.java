    package com.dev.trainingcenter.trainee.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.admin.adapter.NotificationADapter;
import com.dev.trainingcenter.common.Helper;
import com.dev.trainingcenter.common.RequestCourseModel;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.FragmentNotificationBinding;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


    public class NotificationFragment extends Fragment {
    FragmentNotificationBinding binding;
    DatabaseHelper helper;
    List<RequestCourseModel> list;
    NotificationADapter aDapter;
    public NotificationFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this
        binding=FragmentNotificationBinding.inflate(inflater,container,false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        helper=new DatabaseHelper(requireContext());
        list=new ArrayList<>();
        for (RequestCourseModel requestCourseModel:helper.getAllRequests()) {
            if (requestCourseModel.getUserId()!=0) {
                if (Objects.equals(requestCourseModel.getUserId(), Helper.userModel.getId())) {
                    list.add(requestCourseModel);
                }
            }else {
                list.add(requestCourseModel);
            }
        }
        aDapter=new NotificationADapter(list,requireContext(),helper);
        binding.rvNotifcations.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvNotifcations.setAdapter(aDapter);

        if (list.size()==0){
            binding.noData.tvTitle.setText("No Notifications so far..");
            binding.noData.getRoot().setVisibility(View.VISIBLE);
        }
    }
}