package com.dev.trainingcenter;

import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.dev.trainingcenter.admin.AdminMainActivity;
import com.dev.trainingcenter.auth.LoginActivity;
import com.dev.trainingcenter.auth.UserModel;
import com.dev.trainingcenter.common.Constants;
import com.dev.trainingcenter.common.Helper;
import com.dev.trainingcenter.common.SharedPreferencesHelper;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.ActivityMainBinding;
import com.dev.trainingcenter.instructor.InstructorMainActivity;
import com.dev.trainingcenter.trainee.TraineeMainActivity;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    Animation fromTop;
    Animation fromBottom;

    DatabaseHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.app_color));

        helper = new DatabaseHelper(this);
        fromTop = AnimationUtils.loadAnimation(this, R.anim.fromtop);
        fromBottom = AnimationUtils.loadAnimation(this, R.anim.frombottom);

        binding.ivLogo.setAnimation(fromTop);
        binding.tvAppName.setAnimation(fromBottom);

        final Thread thread = new Thread() {
            @Override
            public void run() {
                try {
                    sleep(3000);
                    int id = SharedPreferencesHelper.getInstance(MainActivity.this).readInt(Constants.LOGGED_INID, -1);
                    switch (id) {
                        case 0:
                            startActivity(new Intent(MainActivity.this, AdminMainActivity.class));
                            finish();

                            break;
                        case -1:
                            startActivity(new Intent(MainActivity.this, LoginActivity.class));
                            finish();
                            break;
                        default:
                            UserModel userModel = helper.getUserById(id);
                            if (userModel != null) {
                                Helper.userModel = userModel;
                                if (Objects.equals(userModel.getType(), Constants.INSTRUCTOR)) {
                                    startActivity(new Intent(MainActivity.this, InstructorMainActivity.class));
                                    finish();
                                } else {
                                    startActivity(new Intent(MainActivity.this, TraineeMainActivity.class));
                                    finish();
                                }
                            } else {
                                startActivity(new Intent(MainActivity.this, LoginActivity.class));
                                finish();
                            }

                    }
                } catch (InterruptedException e) {
                    Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

        };

        thread.start();

    }
}