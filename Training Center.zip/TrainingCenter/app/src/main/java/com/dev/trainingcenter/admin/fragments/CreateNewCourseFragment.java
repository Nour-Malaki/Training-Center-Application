package com.dev.trainingcenter.admin.fragments;

import static androidx.navigation.fragment.FragmentKt.findNavController;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.admin.SelectCourseActivity;
import com.dev.trainingcenter.admin.adapter.CoursesAdapter;
import com.dev.trainingcenter.admin.adapter.TopicAdapter;
import com.dev.trainingcenter.common.Constants;
import com.dev.trainingcenter.common.CourseModel;
import com.dev.trainingcenter.common.CourseStatus;
import com.dev.trainingcenter.common.DeleteListener;
import com.dev.trainingcenter.common.OnCLick;
import com.dev.trainingcenter.common.Utils;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.FragmentCreateNewCourseBinding;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class CreateNewCourseFragment extends Fragment implements DeleteListener, OnCLick {

    private FragmentCreateNewCourseBinding binding;
    private int mYear, mMonth, mDay, mHour, mMinute;

    TopicAdapter adapter;
    List<String> list;
    List<CourseModel> courseModelList;

    String image;
    DatabaseHelper helper;
    CourseModel updateModel;
    CoursesAdapter coursesAdapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            updateModel = (CourseModel) getArguments().getSerializable(Constants.MODEL);
        }
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentCreateNewCourseBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        helper = new DatabaseHelper(requireContext());
        list = new ArrayList<>();
        courseModelList = new ArrayList<>();
        adapter = new TopicAdapter(requireContext(), list, this::ClickListener, this::pos, true);
        binding.rvCourse.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvCourse.setAdapter(adapter);

        binding.rvPrequesties.setLayoutManager(new LinearLayoutManager(requireContext()));
        coursesAdapter = new CoursesAdapter(courseModelList, requireContext(), new OnCLick() {
            @Override
            public void ClickListener(int pos) {

            }
        });
        binding.rvPrequesties.setAdapter(coursesAdapter);
        if (updateModel != null) {
            binding.btnCreate.setText("Update");
            binding.btnCreate.setIcon(ContextCompat.getDrawable(requireContext(), R.drawable.baseline_edit_24));
            image = updateModel.getImage();
            binding.logo.setImageURI(Uri.parse(updateModel.getImage()));
            binding.etExpertise.setText(updateModel.getLevel());
            binding.etPrice.setText(updateModel.getPrice());
            binding.etStart.setText(Utils.formatDate(updateModel.getStartDate()));
            binding.etEndDate.setText(Utils.formatDate(updateModel.getEndDate()));
            binding.email.setText(updateModel.getTitle());
            binding.etDetails.setText(updateModel.getDetails());
            list.addAll(Utils.stringToList(updateModel.getTopics()));
            if (updateModel.getPre_requesties() != null) {
                List<String> idsList = Utils.stringToList(updateModel.getPre_requesties());
                for (String id : idsList) {
                    if (!id.equals("")) {
                        CourseModel model1 = helper.getCourseById(Long.parseLong(id));
                        courseModelList.add(model1);
                    }
                }
            }
            coursesAdapter = new CoursesAdapter(courseModelList, requireContext(), pos -> {
            });
            binding.rvPrequesties.setLayoutManager(new LinearLayoutManager(requireContext()));
            binding.rvPrequesties.setAdapter(coursesAdapter);
            adapter.notifyDataSetChanged();
        }


        binding.etStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowDatePicker(binding.etStart);
            }
        });
        binding.etEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowDatePicker(binding.etEndDate);
            }
        });


        binding.logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.setType("image/*");
                startActivityForResult(intent, 10);
            }
        });
        binding.btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String topic = binding.etTopic.getText().toString();
                if (topic.isEmpty()) {
                    Toast.makeText(requireContext(), "Topic should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                binding.etTopic.setText("");
                list.add(topic);
                adapter.notifyDataSetChanged();
            }
        });

        binding.floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(requireContext(), SelectCourseActivity.class);
                if (updateModel != null) {
                    intent.putExtra(Constants.ID, updateModel.getId());
                }
                requireActivity().startActivityFromFragment(CreateNewCourseFragment.this, intent, 100);
            }
        });

        binding.btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = binding.email.getText().toString();
                String details = binding.etDetails.getText().toString();
                String level = binding.etExpertise.getText().toString();
                String start = binding.etStart.getText().toString();
                String end = binding.etEndDate.getText().toString();
                String price = binding.etPrice.getText().toString();
                List<String> ids = new ArrayList<>();
                for (CourseModel courseModel : courseModelList) {
                    ids.add(String.valueOf(courseModel.getId()));
                }

                if (name.isEmpty()) {
                    Toast.makeText(requireContext(), "Name should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (details.isEmpty()) {
                    Toast.makeText(requireContext(), "Details should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (level.isEmpty()) {
                    Toast.makeText(requireContext(), "Level should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (start.isEmpty()) {
                    Toast.makeText(requireContext(), "Select Start Date", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (end.isEmpty()) {
                    Toast.makeText(requireContext(), "Select End Date", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (list.isEmpty()) {
                    Toast.makeText(requireContext(), "Please Add topic to Course", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (price.isEmpty()) {
                    Toast.makeText(requireContext(), "Please Add Price", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (image == null) {
                    Toast.makeText(requireContext(), "Please select image", Toast.LENGTH_SHORT).show();
                    return;
                }


                Long id = null;
                if (updateModel == null) {
                    CourseModel courseModel = new CourseModel();
                    courseModel.setTitle(name);
                    courseModel.setDetails(details);
                    courseModel.setStatus(CourseStatus.PENDING.name());
                    courseModel.setEndDate(formatTime(end));
                    courseModel.setStartDate(formatTime(start));
                    courseModel.setLevel(level);
                    courseModel.setPrice(price);
                    courseModel.setImage(image);
                    courseModel.setTopics(Utils.listToString(list));
                    courseModel.setPre_requesties(Utils.listToString(ids));

                    id = helper.insertCourse(courseModel);
                } else {
                    updateModel.setTitle(name);
                    updateModel.setDetails(details);
                    updateModel.setEndDate(formatTime(end));
                    updateModel.setStartDate(formatTime(start));
                    updateModel.setLevel(level);
                    updateModel.setPrice(price);
                    updateModel.setImage(image);
                    updateModel.setTopics(Utils.listToString(list));
                    updateModel.setPre_requesties(Utils.listToString(ids));
                    id = Long.valueOf(helper.updateCourse(updateModel));
                }
                if (id > 0) {
                    if (updateModel != null) {
                        Toast.makeText(requireContext(), "Course Updated Successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(requireContext(), "Course Inserted Successfully", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(requireContext(), "Error something went wrong", Toast.LENGTH_SHORT).show();

                }
                findNavController(CreateNewCourseFragment.this).navigateUp();

            }
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == 10) {
            Uri uri = null;
            try {
                uri = getImageUriFromBitmap(requireContext(), MediaStore.Images.Media.getBitmap(requireContext().getContentResolver(), data.getData()));
                binding.logo.setImageURI(uri);
                image = uri.toString();
            } catch (IOException e) {
                throw new RuntimeException(e);

            }
        }
        if (resultCode == Activity.RESULT_OK && requestCode == 100) {
            Long id = data.getLongExtra(Constants.ID, -1);
            if (id != -1) {
                CourseModel model = helper.getCourseById(id);
                courseModelList.add(model);
                coursesAdapter.notifyDataSetChanged();

            }
        }
    }


    private Uri getImageUriFromBitmap(Context context, Bitmap bitmap) {
        // Get the directory for storing the image
        File imagesDir = new File(context.getFilesDir(), "YourAppDirectoryName");
        if (!imagesDir.exists()) {
            imagesDir.mkdirs();
        }

        // Create a file to save the image
        File imageFile = new File(imagesDir, System.currentTimeMillis() + ".jpg");

        // Save the bitmap to the file
        OutputStream outputStream = null;
        try {
            outputStream = new FileOutputStream(imageFile);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
            outputStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (outputStream != null) {
                    outputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // Get the URI for the saved image file
        return Uri.fromFile(imageFile);
    }

    private void ShowDatePicker(EditText editText) {
        // Get Current Date
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        DatePickerDialog datePickerDialog = new DatePickerDialog(requireContext(),
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {
                        mDay = dayOfMonth;
                        mMonth = monthOfYear + 1;
                        mYear = year;
                        showTimePicker(editText);

                    }
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }

    private void showTimePicker(EditText editText) {
        final Calendar c = Calendar.getInstance();
        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);

        // Launch Time Picker Dialog
        TimePickerDialog timePickerDialog = new TimePickerDialog(requireContext(),
                new TimePickerDialog.OnTimeSetListener() {

                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay,
                                          int minute) {
                        mHour = hourOfDay;
                        mMinute = minute;
                        editText.setText(mDay + "/" + mMonth + "/" + mYear + " " + mHour + ":" + mMinute);
                    }
                }, mHour, mMinute, false);
        timePickerDialog.show();
    }

    private Long formatTime(String date) {
        long millis = 0;
        SimpleDateFormat f = new SimpleDateFormat("dd/MM/yyyy hh:mm");
        try {
            Date d = f.parse(date);
            millis = d.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return millis;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void pos(int pos) {
        list.remove(pos);
        adapter.notifyItemRemoved(pos);
    }

    @Override
    public void ClickListener(int pos) {

    }
}