package com.dev.trainingcenter.admin.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.common.DeleteListener;
import com.dev.trainingcenter.common.OnCLick;
import com.dev.trainingcenter.databinding.ListTopicBinding;

import java.util.List;

public class TopicAdapter extends RecyclerView.Adapter<TopicAdapter.VH> {
    Context context;
    List<String> list;
    DeleteListener deleteListener;
    OnCLick cLick;
    boolean isEdit;

    public TopicAdapter(Context context, List<String> list, DeleteListener deleteListener, OnCLick cLick,boolean isEdit) {
        this.context = context;
        this.list = list;
        this.deleteListener = deleteListener;
        this.cLick = cLick;
        this.isEdit=isEdit;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.list_topic,parent,false);
        return new VH(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        holder.binding.tvTopic.setText(list.get(position));
        holder.binding.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteListener.pos(position);
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cLick.ClickListener(position);
            }
        });
        if (isEdit){
            holder.binding.delete.setVisibility(View.VISIBLE);
        }else {
            holder.binding.delete.setVisibility(View.GONE);

        }
    }


    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class VH extends RecyclerView.ViewHolder {
        ListTopicBinding binding;

        public VH(@NonNull View itemView) {
            super(itemView);
            binding=ListTopicBinding.bind(itemView);
        }
    }
}
