package com.dev.trainingcenter.admin.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.auth.UserModel;
import com.dev.trainingcenter.common.OnCLick;
import com.dev.trainingcenter.databinding.ListStudentsBinding;

import java.util.List;

public class StudentsAdapter extends RecyclerView.Adapter<StudentsAdapter.Vh> {
    List<UserModel> list;
    Context context;
    OnCLick onCLick;

    public StudentsAdapter(List<UserModel> list, Context context, OnCLick onCLick) {
        this.list = list;
        this.context = context;
        this.onCLick = onCLick;
    }

    @NonNull
    @Override
    public Vh onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_students, parent, false);
        return new Vh(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Vh holder, int position) {
        UserModel userModel = list.get(position);
        holder.setData(userModel);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onCLick.ClickListener(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class Vh extends RecyclerView.ViewHolder {
        ListStudentsBinding binding;

        public Vh(@NonNull View itemView) {
            super(itemView);
            binding = ListStudentsBinding.bind(itemView);
        }

        void setData(UserModel userModel) {
            try {
                binding.ivImage.setImageURI(Uri.parse(userModel.getImage()));
            } catch (SecurityException e) {
                e.printStackTrace();
            }
            binding.tvNAme.setText(userModel.getFirstName() + " " + userModel.getLastName());

            binding.tvEmail.setText(userModel.getEmail());

        }
    }
}
