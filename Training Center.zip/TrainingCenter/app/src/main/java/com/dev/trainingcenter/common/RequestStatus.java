package com.dev.trainingcenter.common;

public enum RequestStatus {
    PENDING,APPROVED,REJECTED;

}
