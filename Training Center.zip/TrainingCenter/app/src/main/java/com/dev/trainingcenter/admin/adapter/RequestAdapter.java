package com.dev.trainingcenter.admin.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.common.OnCLick;
import com.dev.trainingcenter.common.RequestCourseModel;
import com.dev.trainingcenter.common.RequestStatus;
import com.dev.trainingcenter.common.Slots;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.ListRequestsBinding;
import com.skydoves.powermenu.PowerMenu;
import com.skydoves.powermenu.PowerMenuItem;

import java.util.List;

public class RequestAdapter extends RecyclerView.Adapter<RequestAdapter.Vh> {
    List<RequestCourseModel> list;
    Context context;

    DatabaseHelper helper;

    public RequestAdapter(List<RequestCourseModel> list, Context context, DatabaseHelper helper) {
        this.list = list;
        this.context = context;
        this.helper = helper;
    }

    @NonNull
    @Override
    public Vh onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_requests, parent, false);
        return new Vh(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Vh holder, int position) {
        RequestCourseModel requestCourseModel = list.get(position);
        holder.binding.tvUser.setText(requestCourseModel.getCourseName());

        holder.binding.tvStatus.setText(requestCourseModel.getStatus());
        switch (RequestStatus.valueOf(requestCourseModel.getStatus())) {
            case PENDING:
                holder.binding.tvStatus.setTextColor(Color.YELLOW);
                holder.binding.tvRequestDetails
                        .setText(requestCourseModel.getUserName() + " Has requested to get course" + requestCourseModel.getCourseName() + "With Price of " + requestCourseModel.getPrice());
                break;
            case APPROVED:
                holder.binding.tvStatus.setTextColor(Color.GREEN);

                holder.binding.tvRequestDetails
                        .setText("You have Approved course " + requestCourseModel.getCourseName() + " for" + requestCourseModel.getUserName() + "With Price of " + requestCourseModel.getPrice());
                break;
            case REJECTED:
                holder.binding.tvStatus.setTextColor(Color.RED);

                holder.binding.tvRequestDetails
                        .setText("You have Rejected course " + requestCourseModel.getCourseName() + " for" + requestCourseModel.getUserName() + "With Price of " + requestCourseModel.getPrice());
                break;
        }
        holder.binding.tvStatus.setTextColor(Color.RED);

        holder.binding.tvStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMenuType(v, position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class Vh extends RecyclerView.ViewHolder {
        ListRequestsBinding binding;

        public Vh(@NonNull View itemView) {
            super(itemView);
            binding = ListRequestsBinding.bind(itemView);
        }
    }

    private void showMenuType(View view, int pos) {
        PowerMenu powerMenu = new PowerMenu.Builder(context)
                .setTextColor(Color.BLACK)
                .setMenuRadius(10f)
                .setTextGravity(Gravity.CENTER)
                .addItem(new PowerMenuItem(RequestStatus.PENDING.name()))
                .addItem(new PowerMenuItem(RequestStatus.APPROVED.name()))
                .addItem(new PowerMenuItem(RequestStatus.REJECTED.name()))

                .build();

        powerMenu.setOnMenuItemClickListener((position, item) -> {
            RequestCourseModel model = list.get(pos);
            model.setStatus(item.getTitle().toString());
            helper.updateRequest(model);
            notifyItemChanged(pos);
            powerMenu.dismiss();
        });

        powerMenu.showAtCenter(view);
    }
}
