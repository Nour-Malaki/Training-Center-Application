package com.dev.trainingcenter.admin.fragments;

import static androidx.navigation.fragment.FragmentKt.findNavController;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.admin.adapter.StudentsAdapter;
import com.dev.trainingcenter.auth.UserModel;
import com.dev.trainingcenter.common.Constants;
import com.dev.trainingcenter.common.OnCLick;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.FragmentInstructorsBinding;

import java.util.List;

public class InstructorsFragment extends Fragment {
    FragmentInstructorsBinding binding;
    StudentsAdapter adapter;
    List<UserModel> list;
    DatabaseHelper helper;


    public InstructorsFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding=FragmentInstructorsBinding.inflate(inflater,container,false);
        return binding.getRoot();

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        helper = new DatabaseHelper(requireContext());
        list = helper.getUsersByType(Constants.INSTRUCTOR);
        adapter = new StudentsAdapter(list, requireContext(), new OnCLick() {
            @Override
            public void ClickListener(int pos) {
                Bundle bundle=new Bundle();
                bundle.putSerializable("model",list.get(pos));
                findNavController(InstructorsFragment.this).navigate(R.id.action_nav_instructors_to_profileDetailFragments,bundle);
            }
        });
        binding.rvInstructors.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvInstructors.setAdapter(adapter);
    }
}