package com.dev.trainingcenter.common;

import com.dev.trainingcenter.auth.UserModel;

public class Helper {
    public static UserModel userModel;
}
