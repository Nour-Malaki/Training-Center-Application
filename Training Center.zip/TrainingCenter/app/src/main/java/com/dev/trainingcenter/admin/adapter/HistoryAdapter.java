package com.dev.trainingcenter.admin.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.common.RequestCourseModel;
import com.dev.trainingcenter.common.RequestStatus;
import com.dev.trainingcenter.common.Utils;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.ListHistoryBinding;
import com.dev.trainingcenter.databinding.ListNotificationsBinding;

import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.Vh> {
    List<RequestCourseModel> list;
    Context context;

    DatabaseHelper helper;

    public HistoryAdapter(List<RequestCourseModel> list, Context context, DatabaseHelper helper) {
        this.list = list;
        this.context = context;
        this.helper = helper;
    }

    @NonNull
    @Override
    public HistoryAdapter.Vh onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_history, parent, false);
        return new HistoryAdapter.Vh(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryAdapter.Vh holder, int position) {
        RequestCourseModel requestCourseModel = list.get(position);
        holder.binding.tvUser.setText(requestCourseModel.getCourseName());
        switch (RequestStatus.valueOf(requestCourseModel.getStatus())) {
            case PENDING:
                holder.binding.tvRequestDetails
                        .setText(requestCourseModel.getUserName() + " Has requested to get course" + requestCourseModel.getCourseName() + "With Price of " + requestCourseModel.getPrice());
                break;
            case APPROVED:

                holder.binding.tvRequestDetails
                        .setText("You have Approved course " + requestCourseModel.getCourseName() + " for" + requestCourseModel.getUserName() + "With Price of " + requestCourseModel.getPrice());
                break;
            case REJECTED:

                holder.binding.tvRequestDetails
                        .setText("You have Rejected course " + requestCourseModel.getCourseName() + " for" + requestCourseModel.getUserName() + "With Price of " + requestCourseModel.getPrice());
                break;
        }
        holder.binding.tvTime.setText(Utils.formatDate(requestCourseModel.getTime()));

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class Vh extends RecyclerView.ViewHolder {
        ListHistoryBinding binding;

        public Vh(@NonNull View itemView) {
            super(itemView);
            binding = ListHistoryBinding.bind(itemView);
        }
    }

}