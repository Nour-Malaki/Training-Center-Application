package com.dev.trainingcenter.instructor.fragments;

import static androidx.navigation.fragment.FragmentKt.findNavController;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.admin.adapter.CoursesAdapter;
import com.dev.trainingcenter.common.Constants;
import com.dev.trainingcenter.common.CourseModel;
import com.dev.trainingcenter.common.CourseStatus;
import com.dev.trainingcenter.common.Helper;
import com.dev.trainingcenter.common.OnCLick;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.FragmentCurrentScheduleBinding;

import java.util.List;

public class CurrentScheduleFragment extends Fragment {
    FragmentCurrentScheduleBinding binding;
    DatabaseHelper helper;
    List<CourseModel> list;
    CoursesAdapter adapter;

    public CurrentScheduleFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentCurrentScheduleBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        helper = new DatabaseHelper(requireContext());

        list = helper.getScheduleCourses(String.valueOf(Helper.userModel.getId()), CourseStatus.OPEN.name());
        adapter=new CoursesAdapter(list, requireContext(), new OnCLick() {
            @Override
            public void ClickListener(int pos) {
                Bundle bundle=new Bundle();
                bundle.putLong(Constants.ID,list.get(pos).getId());
                findNavController(CurrentScheduleFragment.this).navigate(R.id.action_nav_current_schedule_to_courseDetailsFragment2,bundle);
            }
        });
        binding.rvSchedule.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvSchedule.setAdapter(adapter);

        if (list.size()==0){
            binding.noData.getRoot().setVisibility(View.VISIBLE);
            binding.noData.tvTitle.setText("You have no Course Schedule so far..");
        }

    }
}