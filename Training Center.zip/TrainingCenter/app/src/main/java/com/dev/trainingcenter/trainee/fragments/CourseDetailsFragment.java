package com.dev.trainingcenter.trainee.fragments;

import static com.google.android.material.button.MaterialButton.ICON_GRAVITY_TEXT_START;

import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.admin.adapter.CoursesAdapter;
import com.dev.trainingcenter.admin.adapter.StudentsAdapter;
import com.dev.trainingcenter.admin.adapter.TopicAdapter;
import com.dev.trainingcenter.auth.UserModel;
import com.dev.trainingcenter.common.Constants;
import com.dev.trainingcenter.common.CourseModel;
import com.dev.trainingcenter.common.DeleteListener;
import com.dev.trainingcenter.common.Helper;
import com.dev.trainingcenter.common.OnCLick;
import com.dev.trainingcenter.common.RequestCourseModel;
import com.dev.trainingcenter.common.RequestStatus;
import com.dev.trainingcenter.common.Utils;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.FragmentCourseDetailsBinding;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class CourseDetailsFragment extends Fragment implements OnCLick, DeleteListener {
    FragmentCourseDetailsBinding binding;
    Long id;
    CourseModel model;
    DatabaseHelper helper;
    TopicAdapter adapter;
    List<String> list;
    StudentsAdapter studentsAdapter;
    RequestCourseModel requestModel;
    boolean isRequested = false;

    CoursesAdapter coursesAdapter;
    List<CourseModel> courseModelList = new ArrayList<>();


    public CourseDetailsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            id = getArguments().getLong(Constants.ID);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentCourseDetailsBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        helper = new DatabaseHelper(requireContext());
        model = helper.getCourseById(id);
        SQLiteDatabase db = helper.getWritableDatabase();

        if (helper.isDuplicateRequest(db, Helper.userModel.getId(), model.getId())) {
            isRequested = true;
            requestModel = helper.getRequest(Helper.userModel.getId(), model.getId());
            binding.btnEnroll.setEnabled(false);
            switch (RequestStatus.valueOf(requestModel.getStatus())) {
                case PENDING:
                    binding.btnEnroll.setEnabled(true);
                    binding.btnEnroll.setIcon(ContextCompat.getDrawable(requireContext(), R.drawable.baseline_history_24));
                    binding.btnEnroll.setIconGravity(ICON_GRAVITY_TEXT_START);
                    binding.btnEnroll.setText("WithDraw Request");
                    break;
                case APPROVED:
                    binding.btnEnroll.setIcon(ContextCompat.getDrawable(requireContext(), R.drawable.baseline_done_24));
                    binding.btnEnroll.setIconGravity(ICON_GRAVITY_TEXT_START);
                    binding.btnEnroll.setText("Request Approved");
                    break;
                case REJECTED:
                    binding.btnEnroll.setIcon(ContextCompat.getDrawable(requireContext(), R.drawable.baseline_cancel_24));
                    binding.btnEnroll.setIconGravity(ICON_GRAVITY_TEXT_START);
                    binding.btnEnroll.setText("Rejected");
                    break;

            }
        }
        if (model != null) {
            if (Helper.userModel.getType().equals(Constants.INSTRUCTOR)) {
                binding.btnEnroll.setVisibility(View.GONE);
            }
            list = Utils.stringToList(model.getTopics());
            if (model.getPre_requesties() != null) {

                List<String> idsList = Utils.stringToList(model.getPre_requesties());
                for (String id : idsList) {
                    if (!Objects.equals(id, "")) {
                        CourseModel model1 = helper.getCourseById(Long.parseLong(id));
                        courseModelList.add(model1);
                    }
                }
            }
            coursesAdapter = new CoursesAdapter(courseModelList, requireContext(), pos -> {
            });
            binding.rvCourse.setLayoutManager(new LinearLayoutManager(requireContext()));
            binding.rvCourse.setAdapter(coursesAdapter);

            adapter = new TopicAdapter(requireContext(), list, this, this::ClickListener, false);
            binding.rvTopics.setLayoutManager(new LinearLayoutManager(requireContext()));
            binding.rvTopics.setAdapter(adapter);

            binding.tvName.setText(model.getTitle());
            binding.tvDetails.setText(model.getDetails());
            binding.imageView.setImageURI(Uri.parse(model.getImage()));
            binding.tvVenue.setText(model.getVenue());
            binding.tvSLot.setText(model.getSlot());
            binding.tvStart.setText(new SimpleDateFormat("dd/MM/yyyy hh:mm").format(model.getStartDate()));
            binding.tvEnd.setText(new SimpleDateFormat("dd/MM/yyyy hh:mm").format(model.getEndDate()));
            binding.tvType.setText(model.getPrice() + "$");
            if (Helper.userModel.getType().equals(Constants.INSTRUCTOR)) {
                binding.rvEnrolled.setVisibility(View.VISIBLE);
                binding.tvEnrolled.setVisibility(View.VISIBLE);

                List<UserModel> list1 = helper.getUserByCourseRequest((int) model.getId());
                binding.rvEnrolled.setLayoutManager(new LinearLayoutManager(requireContext()));
                studentsAdapter = new StudentsAdapter(list1, requireContext(), new OnCLick() {
                    @Override
                    public void ClickListener(int pos) {

                    }
                });
                binding.rvEnrolled.setAdapter(studentsAdapter);
            }
        }

        binding.btnEnroll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (requestModel != null) {
                    helper.deleteRequest(requestModel);
                    requestModel = null;
                    binding.btnEnroll.setEnabled(true);

                    binding.btnEnroll.setIcon(ContextCompat.getDrawable(requireContext(), R.drawable.baseline_history_24));
                    binding.btnEnroll.setIconGravity(ICON_GRAVITY_TEXT_START);
                    binding.btnEnroll.setText("Enroll Course!!");
                } else {
                    RequestCourseModel requestCourseModel = new RequestCourseModel();
                    requestCourseModel.setCourseId(model.getId());
                    requestCourseModel.setCourseName(model.getTitle());
                    requestCourseModel.setStatus(RequestStatus.PENDING.name());
                    requestCourseModel.setUserName(Helper.userModel.getFirstName() + " " + Helper.userModel.getLastName());
                    requestCourseModel.setUserId(Helper.userModel.getId());
                    requestCourseModel.setPrice(model.getPrice());
                    requestCourseModel.setTime(System.currentTimeMillis());
                    boolean isAllCoursesEnrolled = true;
                    for (CourseModel id : courseModelList) {
                     /*   SQLiteDatabase db = helper.getWritableDatabase();
                        if (!helper.isDuplicateRequest(db, Helper.userModel.getId(), id.getId())) {
                            isAllCoursesEnrolled = false;
                        }*/
                        RequestCourseModel model1 = helper.getRequest(Helper.userModel.getId(), id.getId());
                        if (model1 != null) {
                            if (!RequestStatus.APPROVED.name().equals(model1.getStatus())) {
                                isAllCoursesEnrolled = false;
                            }
                        } else {
                            isAllCoursesEnrolled = false;
                        }
                    }
                    if (isAllCoursesEnrolled) {
                        helper.addRequest(requestCourseModel);
                        binding.btnEnroll.setEnabled(false);
                        binding.btnEnroll.setIcon(ContextCompat.getDrawable(requireContext(), R.drawable.baseline_history_24));
                        binding.btnEnroll.setIconGravity(ICON_GRAVITY_TEXT_START);
                        binding.btnEnroll.setText("Request Pending!!");
                    } else {
                        Toast.makeText(requireContext(), "Please Enroll Previous Courses to enroll this one..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }

    @Override
    public void ClickListener(int pos) {

    }

    @Override
    public void pos(int pos) {

    }
}