package com.dev.trainingcenter.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.dev.trainingcenter.auth.UserModel;
import com.dev.trainingcenter.common.CourseModel;
import com.dev.trainingcenter.common.CourseStatus;
import com.dev.trainingcenter.common.RequestCourseModel;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "Training_Center";
    private static final String TABLE_USERS = "users_table";
    private static final String KEY_USER_EMAIL = "email";
    private static final String KEY_FIRST_NAME = "first_name";
    private static final String KEY_LAST_NAME = "last_name";
    private static final String KEY_PHONE = "phone";
    private static final String KEY_ADDRESS = "address";
    private static final String KEY_DEGREE = "degree";
    private static final String KEY_COURSES = "courses";
    private static final String KEY_SPECIALIZATION = "specialization";
    private static final String KEY_PASSWORD = "password";
    private static final String KEY_IMAGE = "image";
    private static final String KEY_TYPE = "type";

    // COURSES
    public static final String TABLE_COURSE = "courses";
    public static final String TABLE_REQUEST = "request_table";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_START_DATE = "startDate";
    private static final String COLUMN_END_DATE = "endDate";
    private static final String COLUMN_DEADLINE = "deadline";
    private static final String COLUMN_INSTRUCTOR_ID = "instructorId";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_DETAILS = "details";
    private static final String COLUMN_TOPICS = "topics";
    private static final String COLUMN_LEVEL = "level";
    private static final String COLUMN_IMAGE = "image";
    private static final String COLUMN_INSTRUCTOR_NAME = "instructorName";
    private static final String COLUMN_PRICE = "price";
    private static final String COLUMN_STATUS = "status";
    private static final String COLUMN_VENUE = "venue";
    private static final String COLUMN_SLOT = "slot";
    private static final String COLUMN_COURSE_ID = "course_id";
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USER_NAME = "user_name";
    private static final String COLUMN_COURSE_NAME = "course_name";
    private static final String COLUMN_TIME = "time";
    private static final String COLUMN_PREREQUESTIES = "prerequestires";


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //UsersTable
        db.execSQL(" CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY, " +
                KEY_USER_EMAIL + " TEXT, " +
                KEY_FIRST_NAME + " TEXT NOT NULL, " +
                KEY_LAST_NAME + " TEXT NOT NULL, " +
                KEY_PHONE + " TEXT NOT NULL, " +
                KEY_ADDRESS + " TEXT NOT NULL, " +
                KEY_DEGREE + " TEXT NOT NULL, " +
                KEY_COURSES + " TEXT NOT NULL, " +
                KEY_SPECIALIZATION + " TEXT NOT NULL, " +
                KEY_IMAGE + " TEXT NOT NULL, " +
                KEY_TYPE + " TEXT NOT NULL, " +
                KEY_PASSWORD + " TEXT NOT NULL);"
        );
        String CREATE_TABLE_QUERY = "CREATE TABLE " + TABLE_COURSE + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_START_DATE + " INTEGER,"
                + COLUMN_END_DATE + " INTEGER,"
                + COLUMN_DEADLINE + " INTEGER,"
                + COLUMN_INSTRUCTOR_ID + " INTEGER,"
                + COLUMN_TITLE + " TEXT,"
                + COLUMN_DETAILS + " TEXT,"
                + COLUMN_TOPICS + " TEXT,"
                + COLUMN_LEVEL + " TEXT,"
                + COLUMN_IMAGE + " TEXT,"
                + COLUMN_INSTRUCTOR_NAME + " TEXT,"
                + COLUMN_PRICE + " TEXT,"
                + COLUMN_SLOT + " TEXT,"
                + COLUMN_VENUE + " TEXT,"
                + COLUMN_PREREQUESTIES + " TEXT,"
                + COLUMN_STATUS + " TEXT"
                + ")";

        db.execSQL(CREATE_TABLE_QUERY);

        String CREATE_TABLE_REQUEST =
                "CREATE TABLE " + TABLE_REQUEST + "(" +
                        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                        COLUMN_COURSE_ID + " INTEGER," +
                        COLUMN_USER_ID + " INTEGER," +
                        COLUMN_USER_NAME + " TEXT," +
                        COLUMN_COURSE_NAME + " TEXT," +
                        COLUMN_PRICE + " TEXT," +
                        COLUMN_TIME + " INTEGER," +
                        COLUMN_STATUS + " TEXT" +
                        ")";
        db.execSQL(CREATE_TABLE_REQUEST);

    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);

        onCreate(db);

    }

    public void register(UserModel users) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_USER_EMAIL, users.getEmail());
        values.put(KEY_FIRST_NAME, users.getFirstName());
        values.put(KEY_LAST_NAME, users.getLastName());
        values.put(KEY_PHONE, users.getPhone());
        values.put(KEY_ADDRESS, users.getAddress());
        values.put(KEY_DEGREE, users.getDegree());
        values.put(KEY_COURSES, users.getCourses());
        values.put(KEY_SPECIALIZATION, users.getSpecialization());
        values.put(KEY_TYPE, users.getType());
        values.put(KEY_IMAGE, users.getImage());
        values.put(KEY_PASSWORD, users.getPassword());

        db.insert(TABLE_USERS, null, values);
        db.close();
    }

    public Integer updateUser(UserModel users) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_USER_EMAIL, users.getEmail());
        values.put(KEY_FIRST_NAME, users.getFirstName());
        values.put(KEY_LAST_NAME, users.getLastName());
        values.put(KEY_PHONE, users.getPhone());
        values.put(KEY_ADDRESS, users.getAddress());
        values.put(KEY_DEGREE, users.getDegree());
        values.put(KEY_COURSES, users.getCourses());
        values.put(KEY_SPECIALIZATION, users.getSpecialization());
        values.put(KEY_TYPE, users.getType());
        values.put(KEY_IMAGE, users.getImage());
        values.put(KEY_PASSWORD, users.getPassword());

        Integer id = db.update(TABLE_USERS, values, COLUMN_ID + "=?",
                new String[]{String.valueOf(users.getId())});
        db.close();
        return id;
    }

    public List<UserModel> getAllUsers() {
        List<UserModel> usersList = new ArrayList<>();
        String selectQuery = "SELECT  * FROM " + TABLE_USERS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                UserModel users = new UserModel();
                users.setId(Long.parseLong(cursor.getString(0)));
                users.setEmail(cursor.getString(1));
                users.setFirstName(cursor.getString(2));
                users.setLastName(cursor.getString(3));
                users.setPhone(cursor.getString(4));
                users.setAddress(cursor.getString(5));
                users.setDegree(cursor.getString(6));
                users.setCourses(cursor.getString(7));
                users.setSpecialization(cursor.getString(8));
                users.setImage(cursor.getString(9));
                users.setType(cursor.getString(10));
                users.setPassword(cursor.getString(11));

                usersList.add(users);
            } while (cursor.moveToNext());
        }

        return usersList;
    }

    public UserModel getUserById(Integer id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null, COLUMN_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            UserModel users = new UserModel();
            users.setId(Long.parseLong(cursor.getString(0)));
            users.setEmail(cursor.getString(1));
            users.setFirstName(cursor.getString(2));
            users.setLastName(cursor.getString(3));
            users.setPhone(cursor.getString(4));
            users.setAddress(cursor.getString(5));
            users.setDegree(cursor.getString(6));
            users.setCourses(cursor.getString(7));
            users.setSpecialization(cursor.getString(8));
            users.setImage(cursor.getString(9));
            users.setType(cursor.getString(10));
            users.setPassword(cursor.getString(11));

            return users;

        } else {
            return null;
        }

    }

    public List<UserModel> getUsersByType(String type) {
        List<UserModel> usersList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = KEY_TYPE + " = ?";
        String[] selectionArgs = {type};
        String[] projection = {
                COLUMN_ID,
                KEY_USER_EMAIL,
                KEY_FIRST_NAME,
                KEY_LAST_NAME,
                KEY_PHONE,
                KEY_ADDRESS,
                KEY_DEGREE,
                KEY_COURSES,
                KEY_SPECIALIZATION,
                KEY_IMAGE,
                KEY_TYPE,
                KEY_PASSWORD
        };

        Cursor cursor = db.query(TABLE_USERS, projection, selection, selectionArgs, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                UserModel users = new UserModel();
                users.setId(Long.parseLong(cursor.getString(0)));
                users.setEmail(cursor.getString(1));
                users.setFirstName(cursor.getString(2));
                users.setLastName(cursor.getString(3));
                users.setPhone(cursor.getString(4));
                users.setAddress(cursor.getString(5));
                users.setDegree(cursor.getString(6));
                users.setCourses(cursor.getString(7));
                users.setSpecialization(cursor.getString(8));
                users.setImage(cursor.getString(9));
                users.setType(cursor.getString(10));
                users.setPassword(cursor.getString(11));

                usersList.add(users);
            } while (cursor.moveToNext());
        }

        return usersList;

    }

    //INSERT COURSE
    public long insertCourse(CourseModel dataModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_START_DATE, dataModel.getStartDate());
        values.put(COLUMN_END_DATE, dataModel.getEndDate());
        values.put(COLUMN_DEADLINE, dataModel.getDeadline());
        values.put(COLUMN_INSTRUCTOR_ID, dataModel.getInstructorId());
        values.put(COLUMN_TITLE, dataModel.getTitle());
        values.put(COLUMN_DETAILS, dataModel.getDetails());
        values.put(COLUMN_TOPICS, dataModel.getTopics());
        values.put(COLUMN_LEVEL, dataModel.getLevel());
        values.put(COLUMN_IMAGE, dataModel.getImage());
        values.put(COLUMN_INSTRUCTOR_NAME, dataModel.getInstructorName());
        values.put(COLUMN_PRICE, dataModel.getPrice());
        values.put(COLUMN_STATUS, dataModel.getStatus());
        values.put(COLUMN_SLOT, dataModel.getSlot());
        values.put(COLUMN_PREREQUESTIES, dataModel.getPre_requesties());
        values.put(COLUMN_VENUE, dataModel.getVenue());
        long id = db.insert(TABLE_COURSE, null, values);
        db.close();
        return id;
    }

    public CourseModel getCourseById(long id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_COURSE, null, COLUMN_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null);
        CourseModel dataModel = null;
        if (cursor != null && cursor.moveToFirst()) {
            dataModel = new CourseModel();
            dataModel.setId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID)));
            dataModel.setStartDate(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_START_DATE)));
            dataModel.setEndDate(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_END_DATE)));
            dataModel.setDeadline(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_DEADLINE)));
            dataModel.setInstructorId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_INSTRUCTOR_ID)));
            dataModel.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)));
            dataModel.setDetails(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DETAILS)));
            dataModel.setTopics(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TOPICS)));
            dataModel.setLevel(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_LEVEL)));
            dataModel.setImage(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_IMAGE)));
            dataModel.setInstructorName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_INSTRUCTOR_NAME)));
            dataModel.setPrice(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PRICE)));
            dataModel.setStatus(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATUS)));
            dataModel.setVenue(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_VENUE)));
            dataModel.setPre_requesties(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PREREQUESTIES)));
            dataModel.setSlot(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SLOT)));
            cursor.close();
        }
        db.close();
        return dataModel;
    }

    public List<CourseModel> getAllCourses() {
        List<CourseModel> dataList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_COURSE, null, null, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                CourseModel dataModel = new CourseModel();
                dataModel.setId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                dataModel.setStartDate(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_START_DATE)));
                dataModel.setEndDate(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_END_DATE)));
                dataModel.setDeadline(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_DEADLINE)));
                dataModel.setInstructorId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_INSTRUCTOR_ID)));
                dataModel.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)));
                dataModel.setDetails(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DETAILS)));
                dataModel.setTopics(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TOPICS)));
                dataModel.setLevel(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_LEVEL)));
                dataModel.setImage(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_IMAGE)));
                dataModel.setInstructorName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_INSTRUCTOR_NAME)));
                dataModel.setPrice(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PRICE)));
                dataModel.setVenue(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_VENUE)));
                dataModel.setSlot(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SLOT)));
                dataModel.setPre_requesties(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PREREQUESTIES)));
                dataModel.setStatus(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATUS)));
                dataList.add(dataModel);
            } while (cursor.moveToNext());
            cursor.close();
        }
        db.close();
        return dataList;
    }

    public Integer updateCourse(CourseModel dataModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_START_DATE, dataModel.getStartDate());
        values.put(COLUMN_END_DATE, dataModel.getEndDate());
        values.put(COLUMN_DEADLINE, dataModel.getDeadline());
        values.put(COLUMN_INSTRUCTOR_ID, dataModel.getInstructorId());
        values.put(COLUMN_TITLE, dataModel.getTitle());
        values.put(COLUMN_DETAILS, dataModel.getDetails());
        values.put(COLUMN_TOPICS, dataModel.getTopics());
        values.put(COLUMN_LEVEL, dataModel.getLevel());
        values.put(COLUMN_IMAGE, dataModel.getImage());
        values.put(COLUMN_INSTRUCTOR_NAME, dataModel.getInstructorName());
        values.put(COLUMN_STATUS, dataModel.getStatus());
        values.put(COLUMN_PRICE, dataModel.getPrice());
        values.put(COLUMN_SLOT, dataModel.getSlot());
        values.put(COLUMN_PREREQUESTIES, dataModel.getPre_requesties());
        values.put(COLUMN_VENUE, dataModel.getVenue());

        Integer id = db.update(TABLE_COURSE, values, COLUMN_ID + "=?",
                new String[]{String.valueOf(dataModel.getId())});
        db.close();
        return id;
    }

    public void deleteCourse(CourseModel dataModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_COURSE, COLUMN_ID + "=?",
                new String[]{String.valueOf(dataModel.getId())});
        db.close();
    }

    public List<CourseModel> getOpenCourses() {
        List<CourseModel> dataList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_STATUS + " = ?";
        String[] selectionArgs = {CourseStatus.OPEN.name()};
        String[] projection = {
                COLUMN_ID,
                COLUMN_START_DATE,
                COLUMN_END_DATE,
                COLUMN_DEADLINE,
                COLUMN_INSTRUCTOR_ID,
                COLUMN_TITLE,
                COLUMN_DETAILS,
                COLUMN_TOPICS,
                COLUMN_LEVEL,
                COLUMN_IMAGE,
                COLUMN_INSTRUCTOR_NAME,
                COLUMN_PRICE,
                COLUMN_SLOT,
                COLUMN_VENUE,
                COLUMN_PREREQUESTIES,
                COLUMN_STATUS
        };


        Cursor cursor = db.query(TABLE_COURSE, projection, selection, selectionArgs, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                CourseModel dataModel = new CourseModel();
                dataModel.setId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                dataModel.setStartDate(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_START_DATE)));
                dataModel.setEndDate(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_END_DATE)));
                dataModel.setDeadline(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_DEADLINE)));
                dataModel.setInstructorId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_INSTRUCTOR_ID)));
                dataModel.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)));
                dataModel.setDetails(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DETAILS)));
                dataModel.setTopics(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TOPICS)));
                dataModel.setLevel(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_LEVEL)));
                dataModel.setImage(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_IMAGE)));
                dataModel.setInstructorName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_INSTRUCTOR_NAME)));
                dataModel.setPrice(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PRICE)));
                dataModel.setVenue(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_VENUE)));
                dataModel.setSlot(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SLOT)));
                dataModel.setSlot(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PREREQUESTIES)));
                dataModel.setStatus(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATUS)));
                dataList.add(dataModel);
            } while (cursor.moveToNext());
            cursor.close();
        }
        db.close();
        return dataList;
    }

    public List<CourseModel> getScheduleCourses(String instructorId, String status) {
        List<CourseModel> dataList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String SELECT_COURSES_QUERY = "SELECT * FROM " + TABLE_COURSE
                + " WHERE " + COLUMN_INSTRUCTOR_ID + " = " + instructorId
                + " AND " + COLUMN_STATUS + " = '" + status + "'";

        Cursor cursor = db.rawQuery(SELECT_COURSES_QUERY, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                CourseModel dataModel = new CourseModel();
                dataModel.setId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                dataModel.setStartDate(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_START_DATE)));
                dataModel.setEndDate(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_END_DATE)));
                dataModel.setDeadline(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_DEADLINE)));
                dataModel.setInstructorId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_INSTRUCTOR_ID)));
                dataModel.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)));
                dataModel.setDetails(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DETAILS)));
                dataModel.setTopics(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TOPICS)));
                dataModel.setLevel(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_LEVEL)));
                dataModel.setImage(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_IMAGE)));
                dataModel.setInstructorName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_INSTRUCTOR_NAME)));
                dataModel.setPrice(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PRICE)));
                dataModel.setVenue(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_VENUE)));
                dataModel.setSlot(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SLOT)));
                dataModel.setPre_requesties(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PREREQUESTIES)));
                dataModel.setStatus(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATUS)));
                dataList.add(dataModel);
            } while (cursor.moveToNext());
            cursor.close();
        }
        db.close();
        return dataList;
    }

    public void addRequest(RequestCourseModel request) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if the user has already requested the course
        if (!isDuplicateRequest(db, request.getUserId(), request.getCourseId())) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_COURSE_ID, request.getCourseId());
            values.put(COLUMN_USER_ID, request.getUserId());
            values.put(COLUMN_USER_NAME, request.getUserName());
            values.put(COLUMN_COURSE_NAME, request.getCourseName());
            values.put(COLUMN_PRICE, request.getPrice());
            values.put(COLUMN_STATUS, request.getStatus());
            values.put(COLUMN_TIME, request.getTime());

            db.insert(TABLE_REQUEST, null, values);
        }

        db.close();
    }

    public void updateRequest(RequestCourseModel request) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_COURSE_ID, request.getCourseId());
        values.put(COLUMN_USER_ID, request.getUserId());
        values.put(COLUMN_USER_NAME, request.getUserName());
        values.put(COLUMN_COURSE_NAME, request.getCourseName());
        values.put(COLUMN_PRICE, request.getPrice());
        values.put(COLUMN_STATUS, request.getStatus());
        values.put(COLUMN_TIME, request.getTime());

        db.update(TABLE_REQUEST, values, COLUMN_USER_ID + " = ? AND " + COLUMN_COURSE_ID + " = ?",
                new String[]{String.valueOf(request.getUserId()), String.valueOf(request.getCourseId())});

        db.close();
    }

    public RequestCourseModel getRequest(long userId, long courseId) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_REQUEST, null, COLUMN_USER_ID + " = ? AND " + COLUMN_COURSE_ID + " = ?",
                new String[]{String.valueOf(userId), String.valueOf(courseId)}, null, null, null);

        RequestCourseModel request = null;
        if (cursor != null && cursor.moveToFirst()) {
            request = new RequestCourseModel();
            request.setId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID)));
            request.setCourseId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_COURSE_ID)));
            request.setUserId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_USER_ID)));
            request.setUserName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_NAME)));
            request.setCourseName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_COURSE_NAME)));
            request.setPrice(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PRICE)));
            request.setStatus(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATUS)));
            request.setTime(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_TIME)));
            cursor.close();
        }

        db.close();
        return request;
    }

    public boolean isDuplicateRequest(SQLiteDatabase db, long userId, long courseId) {
        Cursor cursor = db.query(TABLE_REQUEST, null, COLUMN_USER_ID + " = ? AND " + COLUMN_COURSE_ID + " = ?",
                new String[]{String.valueOf(userId), String.valueOf(courseId)}, null, null, null);
        boolean isDuplicate = cursor != null && cursor.getCount() > 0;
        if (cursor != null) {
            cursor.close();
        }
        return isDuplicate;
    }

    public List<RequestCourseModel> getAllRequests() {
        List<RequestCourseModel> requestList = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_REQUEST, null, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                RequestCourseModel request = new RequestCourseModel();
                request.setId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                request.setCourseId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_COURSE_ID)));
                request.setUserId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_USER_ID)));
                request.setUserName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_NAME)));
                request.setCourseName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_COURSE_NAME)));
                request.setPrice(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PRICE)));
                request.setStatus(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATUS)));
                request.setTime(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_TIME)));

                requestList.add(request);
            } while (cursor.moveToNext());

            cursor.close();
        }

        db.close();
        return requestList;
    }

    public List<CourseModel> getRequestedCoursesByUser(long userId, String type) {
        List<CourseModel> requestedCourses = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT " +
                TABLE_COURSE + "." + COLUMN_ID + ", " +
                TABLE_COURSE + "." + COLUMN_TITLE + ", " +
                TABLE_COURSE + "." + COLUMN_DETAILS + ", " +
                TABLE_COURSE + "." + COLUMN_IMAGE + ", " +
                TABLE_COURSE + "." + COLUMN_STATUS + ", " +
                TABLE_COURSE + "." + COLUMN_PRICE +
                " FROM " + TABLE_COURSE +
                " WHERE " + TABLE_COURSE + "." + COLUMN_ID + " IN " +
                "(SELECT " + TABLE_REQUEST + "." + COLUMN_COURSE_ID +
                " FROM " + TABLE_REQUEST +
                " WHERE " + TABLE_REQUEST + "." + COLUMN_STATUS + " = '" + type + "'" +
                " AND " + TABLE_REQUEST + "." + COLUMN_USER_ID + " = " + userId + ")";

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                CourseModel course = new CourseModel();
                course.setId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                course.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)));
                course.setPrice(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PRICE)));
                course.setDetails(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DETAILS)));
                course.setImage(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_IMAGE)));
                course.setStatus(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATUS)));

                requestedCourses.add(course);

            } while (cursor.moveToNext());

            cursor.close();
        }

        db.close();

        return requestedCourses;
    }

    public List<CourseModel> getApprovedCourses(long userId, String type) {
        List<CourseModel> requestedCourses = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT " +
                TABLE_COURSE + "." + COLUMN_ID + ", " +
                TABLE_COURSE + "." + COLUMN_TITLE + ", " +
                TABLE_COURSE + "." + COLUMN_DETAILS + ", " +
                TABLE_COURSE + "." + COLUMN_IMAGE + ", " +
                TABLE_COURSE + "." + COLUMN_STATUS + ", " +
                TABLE_COURSE + "." + COLUMN_PRICE +
                " FROM " + TABLE_COURSE +
                " WHERE " + TABLE_COURSE + "." + COLUMN_ID + " IN " +
                "(SELECT " + TABLE_REQUEST + "." + COLUMN_COURSE_ID +
                " FROM " + TABLE_REQUEST +
                " WHERE " + TABLE_REQUEST + "." + COLUMN_USER_ID + " = " + userId + ")";


        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                CourseModel course = new CourseModel();
                course.setId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                course.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)));
                course.setPrice(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PRICE)));
                course.setDetails(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DETAILS)));
                course.setImage(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_IMAGE)));
                course.setStatus(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATUS)));

                requestedCourses.add(course);

            } while (cursor.moveToNext());

            cursor.close();
        }

        db.close();

        return requestedCourses;
    }

    public List<UserModel> getUserByCourseRequest(int courseId) {
        List<UserModel> usersList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_USERS +
                " INNER JOIN " + TABLE_REQUEST + " ON " +
                TABLE_USERS + "." + COLUMN_ID + " = " + TABLE_REQUEST + "." + COLUMN_USER_ID +
                " WHERE " + TABLE_REQUEST + "." + COLUMN_COURSE_ID + " = " + courseId;

        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            do {
                UserModel users = new UserModel();
                users.setId(Long.parseLong(cursor.getString(0)));
                users.setEmail(cursor.getString(1));
                users.setFirstName(cursor.getString(2));
                users.setLastName(cursor.getString(3));
                users.setPhone(cursor.getString(4));
                users.setAddress(cursor.getString(5));
                users.setDegree(cursor.getString(6));
                users.setCourses(cursor.getString(7));
                users.setSpecialization(cursor.getString(8));
                users.setImage(cursor.getString(9));
                users.setType(cursor.getString(10));
                users.setPassword(cursor.getString(11));

                usersList.add(users);
            } while (cursor.moveToNext());
        }

        return usersList;
    }

    public void deleteRequest(RequestCourseModel dataModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_REQUEST, COLUMN_ID + "=?",
                new String[]{String.valueOf(dataModel.getId())});
        db.close();
    }

}
