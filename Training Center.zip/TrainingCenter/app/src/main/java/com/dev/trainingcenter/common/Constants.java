package com.dev.trainingcenter.common;

public class Constants {
    public static final String TRAINEE="Trainee";
    public static final String INSTRUCTOR="Instructor";
    public static final String ID="id";
    public static final String MODEL="model";
    public static  final String LOGGED_INID="LOG_ID";
}
