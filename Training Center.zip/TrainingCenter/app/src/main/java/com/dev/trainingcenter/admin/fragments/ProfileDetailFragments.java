package com.dev.trainingcenter.admin.fragments;

import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.auth.UserModel;
import com.dev.trainingcenter.common.Constants;
import com.dev.trainingcenter.databinding.FragmentProfileDetailFragmentsBinding;

import java.util.Objects;

public class ProfileDetailFragments extends Fragment {
    FragmentProfileDetailFragmentsBinding binding;
    UserModel model;

    public ProfileDetailFragments() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            model = (UserModel) getArguments().getSerializable("model");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentProfileDetailFragmentsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (model != null) {
            if (!Objects.equals(model.getType(), Constants.INSTRUCTOR)) {
                binding.specialization.setVisibility(View.GONE);
                binding.courses.setVisibility(View.GONE);
                binding.rlDegree.setVisibility(View.GONE);
            }
            binding.ivImage.setImageURI(Uri.parse(model.getImage()));

            binding.firstName.setText(model.getFirstName());
            binding.lastName.setText(model.getLastName());
            binding.address.setText(model.getAddress());
            binding.phone.setText(model.getPhone());
            binding.email.setText(model.getEmail());
            binding.type.setText(model.getType());
            binding.specialization.setText(model.getSpecialization());
            binding.courses.setText(model.getCourses());

            if (Objects.equals(model.getDegree(), "BSC")) {
                binding.rbBSc.setChecked(true);
            }
            if (Objects.equals(model.getDegree(), "MSC")) {
                binding.rbMSC.setChecked(true);
            }
            if (Objects.equals(model.getDegree(), "PHD")) {
                binding.rbPHD.setChecked(true);
            }
        }
    }
}