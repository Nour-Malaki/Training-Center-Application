package com.dev.trainingcenter.auth;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.admin.AdminMainActivity;
import com.dev.trainingcenter.common.Constants;
import com.dev.trainingcenter.common.Helper;
import com.dev.trainingcenter.common.SharedPreferencesHelper;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.ActivityLoginBinding;
import com.dev.trainingcenter.instructor.InstructorMainActivity;
import com.dev.trainingcenter.trainee.TraineeMainActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class LoginActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    ActivityLoginBinding binding;
    String getType = "", strEmail, strPassword;
    String adminEmail = "admin@gmail.com";
    String adminPassword = "admin@123";

    DatabaseHelper databaseHelper;

    Boolean checkTrainee = false;
    Boolean checkInstructor = false;

    List<UserModel> userList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.app_color));

        databaseHelper = new DatabaseHelper(this);

        binding.spinner.setOnItemSelectedListener(this);

        List<String> categories = new ArrayList<String>();
        categories.add("Trainee");
        categories.add("Instructor");
        categories.add("Admin");

        //Setting adapter on spinner
        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spinner.setAdapter(categoryAdapter);

        binding.register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));

            }
        });

        binding.login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userList = databaseHelper.getAllUsers();
                strEmail = binding.email.getText().toString();
                strPassword = binding.password.getText().toString();

                if (strEmail.isEmpty()) {
                    showToast("Please enter email");
                    binding.email.setError("Please enter email");
                } /*else if (!(Patterns.EMAIL_ADDRESS).matcher(strEmail).matches()) {
                    showToast("Please enter email in correct format");
                    binding.email.setError("Please enter email in correct format");
                } */ else if (strPassword.isEmpty()) {
                    showToast("Please enter password");
                    binding.email.setError("Please enter email");
                } else {

                    if (getType.contentEquals("Admin")) {
                        if (strEmail.contentEquals(adminEmail) && strPassword.contentEquals(adminPassword)) {
                            if (binding.cbRememberMe.isChecked()) {
                                SharedPreferencesHelper.getInstance(LoginActivity.this).writeInt(Constants.LOGGED_INID, 0);
                            } else {
                                SharedPreferencesHelper.getInstance(LoginActivity.this).writeInt(Constants.LOGGED_INID, -1);
                            }
                            startActivity(new Intent(LoginActivity.this, AdminMainActivity.class));
                        } else {
                            showToast("Wrong email or password for admin login");
                        }
                    } else if (getType.contentEquals("Trainee")) {

                        for (UserModel users : userList) {
                            if (strEmail.equals(users.getEmail()) && strPassword.equals(users.getPassword()) && Objects.equals(users.getType(), Constants.TRAINEE)) {
                                checkTrainee = true;
                                showToast("Successfully Login");
                                Helper.userModel = users;
                                if (binding.cbRememberMe.isChecked()) {
                                    SharedPreferencesHelper.getInstance(LoginActivity.this).writeInt(Constants.LOGGED_INID, Math.toIntExact(users.getId()));
                                } else {
                                    SharedPreferencesHelper.getInstance(LoginActivity.this).writeInt(Constants.LOGGED_INID, -1);
                                }
                                startActivity(new Intent(LoginActivity.this, TraineeMainActivity.class));
                                finish();
                                break;
                            }
                        }
                        if (!checkTrainee) {
                            showToast("Wrong Credentials...\nPlease check email or password");
                        }

                    } else if (getType.contentEquals("Instructor")) {

                        for (UserModel users : userList) {
                            if (strEmail.equals(users.getEmail()) && strPassword.equals(users.getPassword()) && Objects.equals(users.getType(), Constants.INSTRUCTOR)) {
                                checkInstructor = true;
                                showToast("Successfully Login");
                                Helper.userModel = users;
                                if (binding.cbRememberMe.isChecked()) {
                                    SharedPreferencesHelper.getInstance(LoginActivity.this).writeInt(Constants.LOGGED_INID, Math.toIntExact(users.getId()));
                                } else {
                                    SharedPreferencesHelper.getInstance(LoginActivity.this).writeInt(Constants.LOGGED_INID, -1);

                                }
                                startActivity(new Intent(LoginActivity.this, InstructorMainActivity.class));
                                finish();
                                break;
                            }
                        }
                        if (!checkInstructor) {
                            showToast("Wrong Credentials...\nPlease check email or password");
                        }
                    }
                }
            }
        });

    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        getType = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}