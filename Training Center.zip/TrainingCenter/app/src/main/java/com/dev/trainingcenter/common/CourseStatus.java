package com.dev.trainingcenter.common;

public enum CourseStatus {
    PENDING,OPEN,CLOSED
}
