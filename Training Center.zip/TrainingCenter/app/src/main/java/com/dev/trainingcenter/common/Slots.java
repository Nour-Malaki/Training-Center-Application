package com.dev.trainingcenter.common;

public enum Slots {
        MORNING,EVENING,NIGHT,NOON,AFTERNOON
}
