package com.dev.trainingcenter.admin.adapter;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.common.CourseModel;
import com.dev.trainingcenter.common.CourseStatus;
import com.dev.trainingcenter.common.OnCLick;
import com.dev.trainingcenter.databinding.ListCoursesBinding;

import java.util.List;

public class CoursesAdapter extends RecyclerView.Adapter<CoursesAdapter.Vh> {
    List<CourseModel> list;
    Context context;
    OnCLick onCLick;

    public CoursesAdapter(List<CourseModel> list, Context context, OnCLick onCLick) {
        this.list = list;
        this.context = context;
        this.onCLick = onCLick;
    }

    public void setList(List<CourseModel> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Vh onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_courses, parent, false);
        return new Vh(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Vh holder, int position) {
        CourseModel courseModel = list.get(position);
        holder.setData(courseModel);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onCLick.ClickListener(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class Vh extends RecyclerView.ViewHolder {
        ListCoursesBinding binding;

        public Vh(@NonNull View itemView) {
            super(itemView);
            binding = ListCoursesBinding.bind(itemView);
        }

        void setData(CourseModel courseModel) {
            binding.imgCourse.setImageURI(Uri.parse(courseModel.getImage()));
            binding.tvNAme.setText(courseModel.getTitle());
            binding.tvDetails.setText(courseModel.getDetails());
            binding.tvPrice.setText(courseModel.getPrice() + "$");
            binding.tvStatus.setText(courseModel.getStatus());

            switch (CourseStatus.valueOf(courseModel.getStatus())) {
                case PENDING:
                    binding.tvStatus.setTextColor(Color.YELLOW);
                    break;
                case CLOSED:
                    binding.tvStatus.setTextColor(Color.RED);
                    break;
                case OPEN:
                    binding.tvStatus.setTextColor(Color.GREEN);
                    break;

            }

        }
    }
}