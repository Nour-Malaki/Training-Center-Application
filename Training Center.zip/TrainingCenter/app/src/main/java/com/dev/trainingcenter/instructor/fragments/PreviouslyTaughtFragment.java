package com.dev.trainingcenter.instructor.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.dev.trainingcenter.admin.adapter.CoursesAdapter;
import com.dev.trainingcenter.common.CourseModel;
import com.dev.trainingcenter.common.CourseStatus;
import com.dev.trainingcenter.common.Helper;
import com.dev.trainingcenter.common.OnCLick;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.FragmentPreviouslyTaughtBinding;

import java.util.List;

public class PreviouslyTaughtFragment extends Fragment {

    FragmentPreviouslyTaughtBinding binding;
    DatabaseHelper helper;
    List<CourseModel> list;
    CoursesAdapter adapter;

    public PreviouslyTaughtFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentPreviouslyTaughtBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        helper = new DatabaseHelper(requireContext());

        list = helper.getScheduleCourses(String.valueOf(Helper.userModel.getId()), CourseStatus.CLOSED.name());
        adapter = new CoursesAdapter(list, requireContext(), new OnCLick() {
            @Override
            public void ClickListener(int pos) {

            }
        });
        binding.rvSchedule.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvSchedule.setAdapter(adapter);

        if (list.size() == 0) {
            binding.noData.getRoot().setVisibility(View.VISIBLE);
            binding.noData.tvTitle.setText("You have no Course Schedule so far..");
        }

    }
}