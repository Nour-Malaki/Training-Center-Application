package com.dev.trainingcenter.admin.fragments;

import static androidx.navigation.fragment.FragmentKt.findNavController;
import static com.dev.trainingcenter.common.Constants.ID;
import static com.dev.trainingcenter.common.Constants.MODEL;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.admin.adapter.TopicAdapter;
import com.dev.trainingcenter.common.CourseModel;
import com.dev.trainingcenter.common.DeleteListener;
import com.dev.trainingcenter.common.OnCLick;
import com.dev.trainingcenter.common.RequestCourseModel;
import com.dev.trainingcenter.common.RequestStatus;
import com.dev.trainingcenter.common.Utils;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.FragmentCourseDetailsAdminBinding;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class CourseDetailsAdminFragment extends Fragment implements DeleteListener, OnCLick {
    FragmentCourseDetailsAdminBinding binding;
    DatabaseHelper helper;
    Long id;
    CourseModel model;
    TopicAdapter adapter;
    List<String> list;

    public CourseDetailsAdminFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            id = getArguments().getLong(ID);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentCourseDetailsAdminBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        helper = new DatabaseHelper(requireContext());
        model = helper.getCourseById(id);

        int approved = 0;
        int rejected = 0;
        int pending = 0;
        List<RequestCourseModel> list1 =new ArrayList<>();
        for (RequestCourseModel courseModel:helper.getAllRequests()) {
            if (courseModel.getUserId()!=0){
                list1.add(courseModel);
            }
        }

        for (RequestCourseModel model1 : list1) {
            if (model1.getCourseId() == model.getId()) {
                switch (RequestStatus.valueOf(model1.getStatus())) {
                    case APPROVED:
                        approved += 1;
                        break;
                    case PENDING:
                        pending += 1;
                        break;
                    case REJECTED:
                        rejected += 1;
                        break;
                }
            }
        }
        binding.tvApproved.setText(approved + "");
        binding.tvPending.setText(pending + "");
        binding.tvRejected.setText(rejected + "");
        if (model != null) {
            list = Utils.stringToList(model.getTopics());
            adapter = new TopicAdapter(requireContext(), list, this, this::ClickListener, false);
            binding.rvTopics.setLayoutManager(new LinearLayoutManager(requireContext()));
            binding.rvTopics.setAdapter(adapter);


            binding.tvName.setText(model.getTitle());
            binding.tvDetails.setText(model.getDetails());
            binding.imageView.setImageURI(Uri.parse(model.getImage()));
            binding.tvStatus.setText(model.getStatus());
            binding.tvType.setText(model.getPrice());
            binding.tvStart.setText(new SimpleDateFormat("dd/MM/yyyy").format(model.getStartDate()));
            binding.tvEnd.setText(new SimpleDateFormat("dd/MM/yyyy").format(model.getEndDate()));


            binding.btnEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putSerializable(MODEL, model);
                    findNavController(CourseDetailsAdminFragment.this).navigate(R.id.action_courseDetailsAdminFragment_to_nav_create_course, bundle);
                }
            });

            binding.btnAvailabilty.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putSerializable(MODEL, model);
                    findNavController(CourseDetailsAdminFragment.this).navigate(R.id.action_courseDetailsAdminFragment_to_updateStatusFragment, bundle);

                }
            });

            binding.btnDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    helper.deleteCourse(model);
                    Toast.makeText(requireContext(), "Course Deleted", Toast.LENGTH_SHORT).show();
                    findNavController(CourseDetailsAdminFragment.this).navigateUp();
                }
            });

        }
    }

    @Override
    public void pos(int pos) {

    }

    @Override
    public void ClickListener(int pos) {

    }
}