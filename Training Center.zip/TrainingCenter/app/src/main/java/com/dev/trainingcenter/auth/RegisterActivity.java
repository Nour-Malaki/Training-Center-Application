package com.dev.trainingcenter.auth;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Patterns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.common.Constants;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.ActivityLoginBinding;
import com.dev.trainingcenter.databinding.ActivityRegisterBinding;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class RegisterActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    ActivityRegisterBinding binding;
    String getType = "", strImage = "", strDegree = "";
    Uri imageUri;
    int PICK_IMAGE_GALLERY = 124;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.app_color));
        databaseHelper = new DatabaseHelper(this);
        binding.spinner.setOnItemSelectedListener(this);

        List<String> categories = new ArrayList<String>();
        categories.add(Constants.TRAINEE);
        categories.add(Constants.INSTRUCTOR);

        //Setting adapter on spinner
        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spinner.setAdapter(categoryAdapter);

        binding.tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            }
        });

        binding.ivImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.setType("*/*");
                startActivityForResult(intent, PICK_IMAGE_GALLERY);
            }
        });

        binding.register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                register();
            }
        });

    }

    private void register() {

        String strEmail = binding.email.getText().toString();
        String strFirstName = binding.firstName.getText().toString();
        String strLastName = binding.lastName.getText().toString();
        String strMobileNumber = binding.phone.getText().toString();
        String strAddress = binding.address.getText().toString();
        String strCourses = binding.courses.getText().toString();
        String strSpecialization = binding.specialization.getText().toString();
        String strPassword = binding.password.getText().toString();
        String strConPassword = binding.conPassword.getText().toString();
        getDegree();


        if (strImage.isEmpty()) {
            showToast("Please pick image");
        } else if (strEmail.isEmpty()) {
            showToast("Please enter email");
            binding.email.setError("Please enter email");
        } else if (!(Patterns.EMAIL_ADDRESS).matcher(strEmail).matches()) {
            showToast("Please enter email in correct format");
            binding.email.setError("Please enter email in correct format");
        } else if (strFirstName.isEmpty()) {
            showToast("Please enter first name");
            binding.firstName.setError("Please enter first name");
        } else if (strLastName.isEmpty()) {
            showToast("Please enter last name");
            binding.lastName.setError("Please enter last name");
        } else if (strMobileNumber.isEmpty()) {
            showToast("Please enter mobile number");
            binding.phone.setError("Please enter mobile number");
        } else if (strAddress.isEmpty()) {
            showToast("Please enter address");
            binding.address.setError("Please enter address");
        } else {

            if (getType.contains(Constants.INSTRUCTOR)) {

                if (strCourses.isEmpty()) {
                    showToast("Please enter courses for teaching");
                } else if (strSpecialization.isEmpty()) {
                    showToast("Please enter specialization");
                } else if (strPassword.isEmpty()) {
                    showToast("Please enter password");
                } else if (strPassword.length() < 8 || strPassword.length() > 15 || !strPassword.matches(".*\\d.*") || !strPassword.matches(".*[a-z].*") || !strPassword.matches(".*[A-Z].*")) {
                    showToast("Password must be between 8 to 15 characters and contain at least one number, one lowercase letter, and one uppercase letter");
                } else if (strConPassword.isEmpty()) {
                    showToast("Please enter confirm password");
                } else if (!strPassword.contentEquals(strConPassword)) {
                    showToast("Password and confirm password must be matched");
                } else {
                    UserModel userModel = new UserModel(getType, strImage, strEmail, strFirstName, strLastName, strMobileNumber,
                            strAddress, strDegree, strCourses, strSpecialization, strPassword);
                    databaseHelper.register(userModel);
                    showToast("Successfully Registered");
                    finish();
                }

            } else {

                if (strPassword.isEmpty()) {
                    showToast("Please enter password");
                } else if (strPassword.length() < 8 || strPassword.length() > 15 || !strPassword.matches(".*\\d.*") || !strPassword.matches(".*[a-z].*") || !strPassword.matches(".*[A-Z].*")) {
                    showToast("Password must be between 8 to 15 characters and contain at least one number, one lowercase letter, and one uppercase letter");
                } else if (strConPassword.isEmpty()) {
                    showToast("Please enter confirm password");
                } else if (!strPassword.contentEquals(strConPassword)) {
                    showToast("Password and confirm password must be matched");
                } else {
                    UserModel userModel = new UserModel(getType, strImage, strEmail, strFirstName, strLastName, strMobileNumber,
                            strAddress, "", "", "", strPassword);
                    databaseHelper.register(userModel);
                    showToast("Successfully Registered");
                    finish();
                }

            }

        }

    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void getDegree() {
        binding.rbBSc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (binding.rbBSc.isChecked()) {
                    strDegree = "BSc";
                }
            }
        });
        binding.rbMSC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (binding.rbMSC.isChecked()) {
                    strDegree = "MSc";
                }
            }
        });
        binding.rbPHD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (binding.rbPHD.isChecked()) {
                    strDegree = "PhD";
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_GALLERY && resultCode == RESULT_OK && data.getData() != null) {
            imageUri = data.getData();
            strImage = imageUri.toString();
            try {
                Bitmap bitmap =
                        MediaStore.Images.Media.getBitmap(getContentResolver(), data.getData());

                strImage= String.valueOf(getImageUriFromBitmap(this,bitmap));
                binding.ivImage.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        getType = parent.getItemAtPosition(position).toString();
        if (getType.contains(Constants.TRAINEE)) {
            binding.specialization.setVisibility(View.GONE);
            binding.courses.setVisibility(View.GONE);
            binding.rlDegree.setVisibility(View.GONE);
        } else if (getType.contains(Constants.INSTRUCTOR)) {
            binding.specialization.setVisibility(View.VISIBLE);
            binding.courses.setVisibility(View.VISIBLE);
            binding.rlDegree.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    private Uri getImageUriFromBitmap(Context context, Bitmap bitmap) {
        // Get the directory for storing the image
        File imagesDir = new File(context.getFilesDir(), "YourAppDirectoryName");
        if (!imagesDir.exists()) {
            imagesDir.mkdirs();
        }

        // Create a file to save the image
        File imageFile = new File(imagesDir, System.currentTimeMillis() + ".jpg");

        // Save the bitmap to the file
        OutputStream outputStream = null;
        try {
            outputStream = new FileOutputStream(imageFile);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
            outputStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (outputStream != null) {
                    outputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // Get the URI for the saved image file
        return Uri.fromFile(imageFile);
    }

}