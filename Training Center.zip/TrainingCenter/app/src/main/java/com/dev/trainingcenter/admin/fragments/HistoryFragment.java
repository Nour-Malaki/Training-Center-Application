package com.dev.trainingcenter.admin.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.dev.trainingcenter.R;
import com.dev.trainingcenter.admin.adapter.HistoryAdapter;
import com.dev.trainingcenter.common.RequestCourseModel;
import com.dev.trainingcenter.database.DatabaseHelper;
import com.dev.trainingcenter.databinding.FragmentHistoryBinding;

import java.util.List;

public class HistoryFragment extends Fragment {
    FragmentHistoryBinding binding;
    HistoryAdapter adapter;
    List<RequestCourseModel> list;
    DatabaseHelper helper;
    public HistoryFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding=FragmentHistoryBinding.inflate(inflater,container,false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        helper=new DatabaseHelper(requireContext());
        list=helper.getAllRequests();

        adapter=new HistoryAdapter(list,requireContext(),helper);
        binding.rvNotifcations.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvNotifcations.setAdapter(adapter);
    }
}